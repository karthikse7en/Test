package utillities_UAT;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import utillities.BaseTestSetup;

public class XpathReader extends Common_Utils{
		public void xpathRead() throws InterruptedException {
			int identifiedFlag = 0;
			String newXpath = null, tagName;
			
			List<WebElement>  linkElements = BaseTestSetup.driver.findElements(By.tagName("input"));
			//WebElement linkElements=  driver.findElement(By.id("identifierId"));
			//tagName = linkElements.getTagName();
			//newXpath = tagName;
			System.out.println(linkElements.size());
			for (int i = 0; i < linkElements.size(); i++) {
				identifiedFlag = 0;
				if(!linkElements.get(i).getAttribute("type").equals("") & linkElements.get(i).getAttribute("type").equals("text")){
					tagName = linkElements.get(i).getTagName();
					newXpath = tagName;
					System.out.println("###################################################################33");
					System.out.println(linkElements.get(i).getAttribute("Name"));
					//Checking the Preceding siblings
					List<WebElement> preceding= linkElements.get(i).findElements(By.xpath("preceding-sibling::*"));
					if (preceding.size() > 0){
						System.out.println("Entering into precedeing");
						String newValue = findElementsTag(preceding);
						System.out.println(newValue);
						if (newValue != null){
							String attribute = newValue.substring(0, newValue.indexOf("~#"));
							System.out.println(attribute);
							String label = newValue.substring(newValue.indexOf("~#")+2, newValue.indexOf("~*"));
							System.out.println(label);
							String value = newValue.substring(newValue.indexOf("~*")+2);
							System.out.println(value);
							String xValue = generateXpath(attribute,label, value);
							System.out.println(xValue);
							newXpath =xValue +"/following-sibling::" + newXpath;
							identifiedFlag = 1;
							System.out.println(newXpath);
						}else{
							
							List<WebElement> child= preceding.get(0).findElements(By.xpath("descendant::*"));
							System.out.println(child.size());
							if (child.size() > 0){
								System.out.println("Entering into Descendant");
								newValue = findElementsTag(child);
								System.out.println(newValue);
								if (newValue != null){
									newXpath = "//label[contains(text(), '" + newValue + "')]/../following-sibling::" + newXpath;
									System.out.println(newXpath);
								}
							}
							
						}
						
					}
					//if preceding xpath is not identified check for the parents
					if (identifiedFlag == 0){					
						WebElement findParents = linkElements.get(i).findElement(By.xpath("parent::*"));
						tagName = findParents.getTagName();
						System.out.println("Entering into parents " + tagName);
						String newValue = findParentTag(findParents);
						System.out.println(newValue);
						if (newValue != null){
							String attribute = newValue.substring(0, newValue.indexOf("~#"));
							System.out.println(attribute);
							String label = newValue.substring(newValue.indexOf("~#")+2, newValue.indexOf("~*"));
							System.out.println(label);
							String value = newValue.substring(newValue.indexOf("~*")+2);
							System.out.println(value);
							String xValue = generateXpath(attribute,label, value);
							System.out.println(xValue);
							newXpath =xValue +"/" + newXpath;
							identifiedFlag = 1;
							System.out.println(newXpath);
						}
						
					
					
					if (identifiedFlag == 0){
							newXpath = tagName + "/" + newXpath;
							System.out.println(newXpath);
							List<WebElement> Parentpreceding= findParents.findElements(By.xpath("preceding-sibling::*"));
							if (Parentpreceding.size() > 0){
								System.out.println("Entering into precedeing");
								newValue = findElementsTag(Parentpreceding);
								System.out.println(newValue);
								if (newValue != null){
									String attribute = newValue.substring(0, newValue.indexOf("~#"));
									System.out.println(attribute);
									String label = newValue.substring(newValue.indexOf("~#")+2, newValue.indexOf("~*"));
									System.out.println(label);
									String value = newValue.substring(newValue.indexOf("~*")+2);
									System.out.println(value);
									String xValue = generateXpath(attribute,label, value);
									System.out.println(xValue);
									newXpath = xValue + "/following-sibling::" + newXpath;
									System.out.println(newXpath);
								}else{
									List<WebElement> child= Parentpreceding.get(0).findElements(By.xpath("descendant::*"));
									System.out.println(child.size());
									String newValue1 = findElementsTag(child);
									System.out.println(newValue1);
									if (newValue1 != null){
										newXpath = "//label[contains(text(), '" + newValue1 + "')]/.." + newXpath;
										System.out.println(newXpath);
									}
								}
									
							}
							
							if (identifiedFlag == 0){
								WebElement findParents_1 = findParents.findElement(By.xpath("parent::*"));
								tagName = findParents_1.getTagName();
								System.out.println("Entering into Grand parents " + tagName);
								newValue = findParentTag(findParents_1);
								System.out.println(newValue);
								if (newValue != null){
									String attribute = newValue.substring(0, newValue.indexOf("~#"));
									System.out.println(attribute);
									String label = newValue.substring(newValue.indexOf("~#")+2, newValue.indexOf("~*"));
									System.out.println(label);
									String value = newValue.substring(newValue.indexOf("~*")+2);
									System.out.println(value);
									String xValue = generateXpath(attribute,label, value);
									System.out.println(xValue);
									newXpath =xValue +"/" + newXpath;
									System.out.println(newXpath);
								}else{
									
									newXpath =  tagName + "/" + newXpath;
								}
								
								
								if (identifiedFlag == 0){
									WebElement findParents_2 = findParents_1.findElement(By.xpath("preceding-sibling::*"));
									tagName = findParents_2.getTagName();
									System.out.println("Entering into Grand parents Pred " + tagName);
									newValue = findParentTag(findParents_2);
									System.out.println(newValue);
									if (newValue != null){
										String attribute = newValue.substring(0, newValue.indexOf("~#"));
										System.out.println(attribute);
										String label = newValue.substring(newValue.indexOf("~#")+2, newValue.indexOf("~*"));
										System.out.println(label);
										String value = newValue.substring(newValue.indexOf("~*")+2);
										System.out.println(value);
										String xValue = generateXpath(attribute,label, value);
										System.out.println(xValue);
										newXpath =xValue + "/following-sibling::" + newXpath;
										System.out.println(newXpath);
									}
								
								}
								
							}
						}	
							
					}		
					
			
				}
			}


		}
		
		public static String findElementsTag(List<WebElement> element){
			String tagName = null;
			for (int j = 0; j< element.size(); j++){
				System.out.println(element.get(j).getTagName());
				if (element.get(j).getAttribute("for") != null){
					tagName =  "Class"  + "~#" + element.get(j).getTagName() + "~*" + element.get(j).getAttribute("for") ;
				}else if (!element.get(j).getText().equals("")){
					System.out.println(element.get(j).getTagName());
					tagName = "Text"  + "~#" + element.get(j).getTagName() + "~*" + element.get(j).getText();
				break;
				}
				
			}
			return tagName;
			
			
		}
		
		public static String findParentTag(WebElement element){
			String tagName = null;
			
				System.out.println(element.getTagName() + " - "+ element.getText());
				System.out.println(element.getAttribute("for"));
				if (element.getAttribute("for") != null){
					tagName =  "Class"  + "~#" + element.getTagName() + "~*" + element.getAttribute("for") ;
					System.out.println(element.getText());
				
				}
				
			
			return tagName;
			
			
		}
		
		public static String generateXpath(String attribute, String label, String value){
			String xpathValue = null;
			switch (attribute) {
			case "Class":
				xpathValue = "//" + label +"[@for='" + value +"']";
				break;
			case "Text":
				xpathValue = "//" + label +"[contains(text(), '" + value +"')]";
				break;
				
			default:
				break;
			}
			
			
			return xpathValue;
			
		}
	}



	
