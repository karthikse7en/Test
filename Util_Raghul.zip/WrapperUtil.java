package utillities;

import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

/**
 * @author 1542375
 */
public class WrapperUtil {

    private static Logger Log = LogManager.getLogger(WrapperUtil.class.getName());

    Datatable dataTable = new Datatable();
    ScreenshotUtil_old screenshot = new ScreenshotUtil_old();
    By byLocator;
    


    /**
     * This method is to select the value from list box
     * 
     * @param locator
     *            and value
     * @throws Exception
     */

    public WrapperUtil selectElementByNameMethod(By locator, String Name) throws Exception {
        if (!Name.equals("SKIP")) {
            try {

                Select selectitem = new Select(BaseTestSetup.driver.findElement(locator));
                selectitem.selectByVisibleText(Name);
                Log.debug("Option " + Name + " Selected in the dropdown");
            }
            catch (Exception e) {
                Log.error("Option " + Name + " not selected in the dropdown :" + e.getMessage());
                throw new Exception("Error while selecting the option" + Name + " in the Drop down" + e.getMessage());
            }
        }
        return this;
    }

    /**
     * This method is to select the value from auto populated drop down list
     * 
     * @param locator
     *            and value
     * @throws Exception
     */
    public WrapperUtil selectElementFromDropdownList(By locator, String value) throws Exception {
        try {
            BaseTestSetup.driver.findElement(locator).click();
            Thread.sleep(3000);
            if (BaseTestSetup.driver.findElement(locator).getText().length() > 0) {
                BaseTestSetup.driver.findElement(locator).clear();
            }
            BaseTestSetup.driver.findElement(locator).sendKeys(value);
            Log.debug("Entered " + value + " in the dropdownlist box");
            Thread.sleep(3000);
            BaseTestSetup.driver.findElement(locator).sendKeys(Keys.ENTER);
        }
        catch (Exception e) {
            Log.error("Option " + value + " is not Selected in the dropdown :" + e.getMessage());
            throw new Exception("Error while selecting the option" + value + " in the Drop down list" + e.getMessage());
        }
        return this;
    }
    
    public void selectElementFromDropdownList(String element, String value) throws Exception {
        try {
        	clickPerform(By.xpath(element));
        	enterValues(By.xpath(element),value);
        	if(!element.contains("bu_name"))
        	{
        	String element1=element+"//following::ul[@class='chosen-results']//li[starts-with(@class,'active-') and .='"+value+"']";
        	System.out.println(element1);
        	BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element1)));
        	clickPerform(By.xpath(element1));
        	}
        	else
        	{
        		BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]"))); 
        		clickPerform(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]")); 
            	
        	}
        	Log.debug("Selected the option " + value + "in the dropdown list");
        }
    catch (Exception e) {
        Log.error("Error while  filling auto fill text box please refer below message for details /n" + e.getMessage());
        throw new Exception("Error while selecting a value:" + value + " in the element:" + element + " :" + e.getMessage());
    }
}
    
    public void selectElementFromDropdownList(String element, String value,String waitMode) throws Exception {
        try {
        	BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element)));
        	clickPerform(By.xpath(element));
        	enterValues(By.xpath(element),value);
        	if(!element.contains("bu_name"))
        	{
        	String element1=element+"//following::ul[@class='chosen-results']//li[starts-with(@class,'active-') and .='"+value+"']";
        	System.out.println(element1);
        	BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element1)));
        	clickPerform(By.xpath(element1));
        	}
        	else
        	{
        		BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]"))); 
        		clickPerform(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]")); 
            	
        	}
        	Log.debug("Selected the option " + value + "in the dropdown list");
        }
    catch (Exception e) {
        Log.error("Error while  filling auto fill text box please refer below message for details /n" + e.getMessage());
        throw new Exception("Error while selecting a value:" + value + " in the element:" + element + " :" + e.getMessage());
    }
}    

    
    public void selectElementFromDropdownList(String element, String value,int i) throws Exception {
        try {
        	String element2 = element.split("'")[0]+"'"+element.split("'")[1]+"_1"+"'"+element.split("'")[2];
        	clickPerform(By.xpath(element2));
        	enterValues(By.xpath(element2),value);
        	if(!element.contains("bu_name"))
        	{
        	String element1=element2+"//following::ul[@class='chosen-results']//li[starts-with(@class,'active-') and .='"+value+"']";
        	System.out.println(element1);
        	BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element1)));
        	clickPerform(By.xpath(element1));
        	}
        	else
        	{
        		BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]"))); 
        		clickPerform(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]")); 
        	}
        	Log.debug("Selected the option " + value + "in the dropdown list");
        }
    catch (Exception e) {
        Log.error("Error while  filling auto fill text box please refer below message for details /n" + e.getMessage());
        throw new Exception("Error while selecting a value:" + value + " in the element:" + element + " :" + e.getMessage());
    }
}
    
    public void selectElementFromDropdownList(String element, String value,String waitMode,int i) throws Exception {
        try {
        	String element2 = element.split("'")[0]+"'"+element.split("'")[1]+"_"+i+"'"+element.split("'")[2];
        	BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element2)));
        	clickPerform(By.xpath(element2));
        	enterValues(By.xpath(element2),value);
        	if(!element.contains("bu_name"))
        	{
        	String element1=element2+"//following::ul[@class='chosen-results']//li[starts-with(@class,'active-') and .='"+value+"']";
        	System.out.println(element1);
        	BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(element1)));
        	clickPerform(By.xpath(element1));
        	}
        	else
        	{
        		BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]"))); 
        		clickPerform(By.xpath("//div[@id='divAutoCompletePicker']//*[contains(text(),'"+value+"')]")); 
        	}
        	Log.debug("Selected the option " + value + "in the dropdown list");
        }
    catch (Exception e) {
        Log.error("Error while  filling auto fill text box please refer below message for details /n" + e.getMessage());
        throw new Exception("Error while selecting a value:" + value + " in the element:" + element + " :" + e.getMessage());
    }
}
    /**
     * This method is to enter the values in text box
     * 
     * @param locator
     *            and value
     * @throws Exception
     */
    public void enterValues(By locator, String name) throws Exception {
        if ((name != null) && (!name.equals("SKIP"))) {
            try {
                clickPerform(locator);
                BaseTestSetup.driver.findElement(locator).sendKeys(name);
                Assert.assertNotNull(BaseTestSetup.driver.findElement(locator).getText());
                Log.debug("Value " + name + " entered into the textbox");
            }
            catch (Exception e) {
                Log.debug("Value " + name + " not entered into the textbox :" + e.getMessage());
                throw new Exception("Error while entering value " + name + " in the field identified by locator" + locator + e.getMessage());
            }
        }
        else {
            Log.error("Please fill a not null value in the testdata sheet");

        }
    }
    public void triggerOnClick(WebElement element) throws Exception{
    	try{
    	String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onmouseover');}";
        String onClickScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('click',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onclick');}";
        ((JavascriptExecutor) BaseTestSetup.driver).executeScript(mouseOverScript,element);
        Thread.sleep(5000);
        ((JavascriptExecutor) BaseTestSetup.driver).executeScript(onClickScript,element);
    	}
    	catch(Exception e){
    		throw new Exception("Erro while triggering onclick for the element: "+element);
    	}
    }
    
    public void triggerOnClick(String eventName,WebElement element) throws Exception{
    	try{
    	String dynamicEventScriupt = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('"+eventName+"',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('"+eventName+"');}";
        ((JavascriptExecutor) BaseTestSetup.driver).executeScript(dynamicEventScriupt,element);
    	}
    	catch(Exception e){
    		throw new Exception("Erro while triggering onclick for the element: "+element);
    	}
    }
    
    
    /**
     * This method is to click the web element
     * 
     * @param locator
     *            and value
     * @throws Exception
     */
    public void clickWebelement(By locator) throws Exception {
        try {
        	((JavascriptExecutor) BaseTestSetup.driver).executeScript("window.scrollTo(0," + BaseTestSetup.driver.findElement(locator).getLocation().y + ")");
        	if(locator.toString().contains("tinymice")){
        		Actions actionsClick = new Actions(BaseTestSetup.driver);
                actionsClick.moveToElement(BaseTestSetup.driver.findElement(locator)).click(BaseTestSetup.driver.findElement(locator));        	
            }
        	else{
        		BaseTestSetup.driver.findElement(locator).sendKeys(Keys.CONTROL);
                BaseTestSetup.driver.findElement(locator).click();
        	}
            Log.debug("Element with locator" + locator + " is clicked");
        }
        catch (Exception e) {
            Log.error("Element with locator" + locator + " is not clicked :" + e.getMessage());
            throw new Exception("Error while Clicking the webelement identified by " + locator + e.getMessage());
        }
    }

    /**
     * This method is to wait for the particular elements presents
     * 
     * @param locator
     *            and value
     */
    public void waitForElement(By locator) throws Exception {
        try {
            BaseTestSetup.wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(locator));
            Log.debug("Waiting for element" + locator);
        }
        catch (Exception e) {
            Log.error("Error while waiting for element and the error message is " + e.getMessage());
            throw new Exception("Error while Clicking the webelement identified by " + locator + e.getMessage());
        }
    }

    /**
     * This method is used to navigate to custom actions and open the specified
     * form
     * 
     * @param locator
     *            and value
     */
    
    
   
    public void customForms(By main_menu, String sub_menu) throws Exception {
        try {
            fluentWait(main_menu, 70);
            BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(main_menu));

            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("window.scrollTo(0," + BaseTestSetup.driver.findElement(main_menu).getLocation().y + ")");
            String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onmouseover');}";
            String onClickScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('click',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onclick');}";
            
           
           WebElement sub_Men =  BaseTestSetup.driver.findElement(By.xpath("//li[@title='"+sub_menu+"']"));
            
            ((JavascriptExecutor) BaseTestSetup.driver).executeScript(onClickScript,sub_Men);
            BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(2));
            screenshot.passfailScreenshot();
        }
        catch (Exception e) {
            screenshot.passfailScreenshot();
            Log.error("Error while selecting " + e.getMessage());
            throw new Exception("Error while selecting the custom form identified by " + sub_menu + " :" + e.getMessage());
        }
    }
    /**
     * This method is to wait for an element until the element is visible in DOM
     * 
     * @param locator
     */

    public void dynamicWait(By locator) throws Exception {

        do {
            BaseTestSetup.wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        }
        while (BaseTestSetup.driver.findElement(locator) == null);
    }

    public void date_selection(By date_flicker, By calendar, String date) throws Exception {
        try {
            BaseTestSetup.wait.until(ExpectedConditions.visibilityOf(BaseTestSetup.driver.findElement(date_flicker)));
            clickWebelement(date_flicker);
            Thread.sleep(2000);
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, -1);
            int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
            String dayOfMonthStr = String.valueOf(dayOfMonth);
            System.out.println(dayOfMonthStr);
            List<WebElement> elements = (List<WebElement>) BaseTestSetup.driver.findElements(calendar);
            for (int i = 0; i <= elements.size(); i++) {
                System.out.println(elements.get(i).getText());
                if (elements.get(i).getText().equalsIgnoreCase(dayOfMonthStr)) {
                    elements.get(i).click();
                    break;
                }
            }
        }
        catch (Exception e) {
            Log.error("Date cannot be selected:" + e.getLocalizedMessage());
            throw new Exception("Error while selecting date in the " + date_flicker + " :" + e.getLocalizedMessage());
        }

    }

    /**
     * To click a button,check-box,link
     * 
     * @param by
     */
    public void clickPerform(By by) throws Exception {
        try {
            if (BaseTestSetup.driver.findElement(by).isDisplayed() && BaseTestSetup.driver.findElement(by).isEnabled()) {
                BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(by));
                clickWebelement(by);
                Log.debug("Element with locator" + by + " is clicked");
            }
            else {
                Log.debug("Element with locator" + by + " is not visible to click");
                ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].style.height='auto'; arguments[0].style.visibility='visible';", BaseTestSetup.driver.findElement(by));
                ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].click();", BaseTestSetup.driver.findElement(by));
                Log.debug("Element with locator" + by + " is clicked using JS executor");
            }
        }
        catch (Exception e) {
            Log.error("Error while clicking" + e.getMessage());
            throw new Exception("Error while clicking the element with identifier " + by + e.getMessage());
        }
    }

    public void getattribute(By locator) throws Exception {
        String TEXT = BaseTestSetup.driver.findElement(locator).getAttribute("value");
        if (TEXT.equals("")) {
            System.out.println("Value not present in this field");
        }
        else {
            System.out.println(TEXT);
        }
    }

    private enum ElementType {
        RADIOBUTTON, TEXTBOX, COMBOBOX, CHECKBOX, TEXTAREA, AUTOFILLTEXTBOX, DATEPICKER;
    }

    /**
     * fill the page with given parameter if parameter is erroneous, stops
     * filling from that particular field
     * 
     * @param list
     * @param sheetName
     * @param filePath
     * @param classname
     */
    public void fill_Page(List<?> list, String sheetName, String filePath, Class classname)
            throws Exception {
        String fieldName = null;
        try {
            dataTable.setFilePath(filePath);
            for (String field : dataTable.getLocator(sheetName)) {
            	
            	
                fieldName = field.split(Pattern.quote("|"))[1];
                System.out.println("Current Field Name : " +fieldName );
               if (!dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list).equals("SKIP")) {
                    if (field.split(Pattern.quote("|")).length > 3) {
                        ElementType elementType = ElementType.valueOf(field.split(Pattern.quote("|"))[2]);
                        
                        System.out.println("Current Element Type : " +elementType );
                        
                        switch (elementType) {
                            case CHECKBOX:
                                System.out.println("Element size----> " + find_Elements(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3]).size());
                                if (find_Elements(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3]).size() == 1) {
                                    clickPerform(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3]));
                                    Log.debug("Clicked on the checkbox: " + find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3]));
                                }
                                else {
                                    for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3])) {
                                        if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list))) {
                                            clickPerform(element);
                                            Log.debug("Clicked on checkbox: " + element);
                                            break;
                                        }
                                    }
                                }
                                break;
                            case COMBOBOX:
                                Select select = new Select(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3]));
                                BaseTestSetup.waitForAjax(select);
                                if (dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list).contains("=")) {
                                    select.selectByIndex(Integer.parseInt(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[2], list).split("=")[1].toString()));
                                    Log.debug("Selected the value " + field.split(Pattern.quote("|"))[2] + " int the combobox");
                                }
                                else {
                                    select.selectByVisibleText(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list));
                                    Log.debug("Selected the value " + field.split(Pattern.quote("|"))[1] + " int the combobox");
                                }
                                break;
                            case RADIOBUTTON:
                                for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3])) {
                                    if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list))) {
                                        clickPerform(element);
                                        Log.debug("Selected the radio button " + element);
                                        break;
                                    }
                                }
                                break;
                            case TEXTAREA:
                                enterValues(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3]), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list));
                                break;
                            case TEXTBOX:
                                enterValues(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3]), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list));
                                break;
                            case AUTOFILLTEXTBOX:
                                selectElementFromDropdownList(field.split(Pattern.quote("|"))[0],dataTable.getData(classname,sheetName,field.split(Pattern.quote("|"))[1],list));
                                break;
                            case DATEPICKER:
                                String locator = field.split(Pattern.quote("|"))[0];
                                if (locator.split("\\?\\?").length > 1) {
                                    String locCalendar = locator.split("\\?\\?")[0];
                                    String locDateField = locator.split("\\?\\?")[1];
                                    System.out.println(getByLocator(locDateField));
                                    date_selection(getByLocator(locDateField), getByLocator(locCalendar), "1");
                                    break;
                                }

                            default:
                                System.out.println("Please verify object repository data");
                                break;
                        }
                    }
                    ElementType elementType = ElementType.valueOf(field.split(Pattern.quote("|"))[2]);
                    switch (elementType) {
                        case CHECKBOX:
                            if (find_Elements(field.split(Pattern.quote("|"))[0]).size() == 1) {
                                clickPerform(find_Element(field.split(Pattern.quote("|"))[0]));
                                Log.debug("Clicked on the checkbox: " + find_Element(field.split(Pattern.quote("|"))[0]));
                            }
                            else {
                                for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0])) {
                                    if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list))) {
                                        clickPerform(element);
                                        Log.debug("Clicked on checkbox: " + element);
                                        break;
                                    }
                                }
                            }
                            break;
                        case COMBOBOX:
                            Select select = new Select(find_Element(field.split(Pattern.quote("|"))[0]));
                            BaseTestSetup.waitForAjax(select);
                            if (dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list).contains("=")) {
                                select.selectByIndex(Integer.parseInt(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list).split("=")[1].toString()));
                            }
                            else {
                                select.selectByVisibleText(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list));
                            }
                            break;
                        case RADIOBUTTON:
                            for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0])) {
                                if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list))) {
                                    clickPerform(element);
                                    break;
                                }
                            }
                            break;
                        case TEXTAREA:
                            enterValues(find_Element(field.split(Pattern.quote("|"))[0]), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list));
                            break;
                        case TEXTBOX:
                            enterValues(find_Element(field.split(Pattern.quote("|"))[0]), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list));
                            break;
                        case AUTOFILLTEXTBOX:
                            selectElementFromDropdownList(field.split(Pattern.quote("|"))[0], dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list));
                        case DATEPICKER:
                            String locator = field.split(Pattern.quote("|"))[0];
                            System.out.println(locator);
                            if (locator.split("\\?\\?").length > 1) {
                                String locCalendar = locator.split("\\?\\?")[0];
                                String locDateField = locator.split("\\?\\?")[1];
                                By bylocDate = getByLocator(locDateField);
                                By bylocCal = getByLocator(locCalendar);
                                date_selection(bylocDate, bylocCal, "1");
                                break;
                            }
                        default:
                            Log.error("ERROR: Improper data provided in the Locators.xlx. Please verify object repository data");
                            break;
                    }
                }
            }
        }
        catch (Exception e) {

            Log.error("Error while filling the field: " + fieldName + " please refer below message" + e.getMessage());
            throw new Exception("Error while filling the field:" + fieldName + " :" + e.getLocalizedMessage());
        }
    }

    private enum Identifier {
        CLASSNAME, CSSSELECTOR, ID, LINKTEXT, NAME, PARTIALLINKTEXT, TAGNAME, XPATH;
    }

    /**
     * Returns list of web elements,provided locator is correct. if locator is
     * erroneous, null value returned
     * 
     * @param locator
     * @return List<WebElement>
     */
    public List<WebElement> find_Elements(String locator) throws Exception {
        List<WebElement> element;
        try {
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            switch (identifier) {
                case CLASSNAME:
                    element = BaseTestSetup.driver.findElements(By.className(locator.split("=")[1]));
                    break;
                case CSSSELECTOR:
                    element = BaseTestSetup.driver.findElements(By.cssSelector(locator.split("=")[1]));
                    break;
                case ID:
                    element = BaseTestSetup.driver.findElements(By.id(locator.split("=")[1]));
                    break;
                case LINKTEXT:
                    element = BaseTestSetup.driver.findElements(By.linkText(locator.split("=")[1]));
                    break;
                case NAME:
                    element = BaseTestSetup.driver.findElements(By.name(locator.split("=")[1]));
                    break;
                case PARTIALLINKTEXT:
                    element = BaseTestSetup.driver.findElements(By.partialLinkText(locator.split("=")[1]));
                    break;
                case TAGNAME:
                    element = BaseTestSetup.driver.findElements(By.tagName(locator.split("=")[1]));
                    break;
                case XPATH:
                    element = BaseTestSetup.driver.findElements(By.xpath(locator.split("=")[1]));
                    break;
                default:
                    element = null;
                    System.out.println("Provide correct locator type/category");
            }
            return element;
        }
        catch (Exception e) {
            Log.error("Error while identifying elements please refer below message /n" + e.getMessage());
            throw new Exception("Error while identifying elements please refer below message /n" + e.getMessage());

        }
    }

    public List<WebElement> find_Elements(String locator, int n) throws Exception {
        List<WebElement> element;
        try {
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            switch (identifier) {
                case CLASSNAME:
                    element = BaseTestSetup.driver.findElements(By.className(locator.split("=")[1] + n));
                    break;
                case CSSSELECTOR:
                    element = BaseTestSetup.driver.findElements(By.cssSelector(locator.split("=")[1] + n));
                    break;
                case ID:
                    element = BaseTestSetup.driver.findElements(By.id(locator.split("=")[1] + n));
                    break;
                case LINKTEXT:
                    element = BaseTestSetup.driver.findElements(By.linkText(locator.split("=")[1] + n));
                    break;
                case NAME:
                    element = BaseTestSetup.driver.findElements(By.name(locator.split("=")[1] + n));
                    break;
                case PARTIALLINKTEXT:
                    element = BaseTestSetup.driver.findElements(By.partialLinkText(locator.split("=")[1] + n));
                    break;
                case TAGNAME:
                    element = BaseTestSetup.driver.findElements(By.tagName(locator.split("=")[1] + n));
                    break;
                case XPATH:
                    element = BaseTestSetup.driver.findElements(By.xpath(locator.split("=")[1] + n));
                    break;
                default:
                    element = null;
                    System.out.println("Provide correct locator type/category");
            }
            return element;
        }
        catch (Exception e) {
            Log.error("Error while identifying elements please refer below message /n" + e.getMessage());
            throw new Exception("Error while identifying elements please refer below message /n" + e.getMessage());

        }
    }

    /**
     * Wait for elements to visible and return the element if locator is wrong,
     * null value returned
     * 
     * @param locator
     * @param waitMode
     * @return List<WebElement>
     */
    public List<WebElement> find_Elements(String locator, String waitMode) throws Exception {
        List<WebElement> element;
        try {
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            switch (identifier) {
                case CLASSNAME:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className(locator)));
                    element = BaseTestSetup.driver.findElements(By.className(locator.split("=")[1]));
                    break;
                case CSSSELECTOR:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(locator)));
                    element = BaseTestSetup.driver.findElements(By.cssSelector(locator.split("=")[1]));
                    break;
                case ID:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id(locator)));
                    element = BaseTestSetup.driver.findElements(By.id(locator.split("=")[1]));
                    break;
                case LINKTEXT:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText(locator)));
                    element = BaseTestSetup.driver.findElements(By.linkText(locator.split("=")[1]));
                    break;
                case NAME:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.name(locator)));
                    element = BaseTestSetup.driver.findElements(By.name(locator.split("=")[1]));
                    break;
                case PARTIALLINKTEXT:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.partialLinkText(locator)));
                    element = BaseTestSetup.driver.findElements(By.partialLinkText(locator.split("=")[1]));
                    break;
                case TAGNAME:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.tagName(locator)));
                    element = BaseTestSetup.driver.findElements(By.tagName(locator.split("=")[1]));
                    break;
                case XPATH:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(locator)));
                    element = BaseTestSetup.driver.findElements(By.xpath(locator.split("=")[1]));
                    break;
                default:
                    element = null;
                    System.out.println("Provide correct locator type/category");
            }
            return element;
        }
        catch (Exception e) {
            Log.error("Error while identifying the elements, please refer below /n" + e.getMessage());
            throw new Exception("Error while finding elements with locator " + locator + " :" + e.getMessage());

        }
    }

    /**
     * Wait for elements to visible and return the element if locator is wrong,
     * null value returned
     * 
     * @param locator
     * @param waitMode
     * @return List<WebElement>
     */
    public List<WebElement> find_Elements(String locator, String waitMode, int i) throws Exception {
        List<WebElement> element;
        try {
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            switch (identifier) {
                case CLASSNAME:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.className(locator.split("=")[1]));
                    break;
                case CSSSELECTOR:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.cssSelector(locator.split("=")[1]));
                    break;
                case ID:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.id(locator.split("=")[1]));
                    break;
                case LINKTEXT:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.linkText(locator.split("=")[1]));
                    break;
                case NAME:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.name(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.name(locator.split("=")[1]));
                    break;
                case PARTIALLINKTEXT:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.partialLinkText(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.partialLinkText(locator.split("=")[1]));
                    break;
                case TAGNAME:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.tagName(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.tagName(locator.split("=")[1]));
                    break;
                case XPATH:
                    BaseTestSetup.wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(locator + i)));
                    element = BaseTestSetup.driver.findElements(By.xpath(locator.split("=")[1]));
                    break;
                default:
                    element = null;
                    System.out.println("Provide correct locator type/category");
            }
            return element;
        }
        catch (Exception e) {
            Log.error("Error while identifying the elements, please refer below /n" + e.getMessage());
            throw new Exception("Error while finding elements with locator " + locator + e.getMessage());

        }
    }

    /**
     * Returns list of web elements,provided locator is correct. if locator is
     * erroneous, null value returned
     * 
     * @param locator
     * @return WebElement
     * @throws Exception
     */
    public WebElement find_Element(String locator) throws Exception {
        WebElement element = null;
        try {
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            if (locator.split("=").length > 2) {
                switch (identifier) {
                    case CLASSNAME:
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        if (locator.split("=").length > 3) {
                            String locatorOne = "";
                            for (int i = 0; i < locator.split("=").length; i++) {
                                if (i > 0 & i == 1) {
                                    locatorOne = locator.split("=")[i];
                                }
                                if (i > 1) {
                                    locatorOne = locatorOne + "=" + locator.split("=")[i];
                                }
                            }
                            BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locatorOne)));
                            element = BaseTestSetup.driver.findElement(By.xpath(locatorOne));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        else {
                            element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1] + "=" + locator.split("=")[2]));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            else {
                switch (identifier) {
                    case CLASSNAME:
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            return element;
        }
        catch (Exception e) {

            Log.error("Error while identifying the field " + e.getMessage());
            throw new Exception("Error while identifing the element with locator:" + locator + e.getMessage());

        }
    }

    public WebElement find_Element(String locator, int n) throws Exception {
        WebElement element = null;
        try {
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            if (locator.split("=").length > 2) {
                switch (identifier) {
                    case CLASSNAME:
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        if (locator.split("=").length > 3) {
                            String locatorOne = "";
                            for (int i = 0; i < locator.split("=").length; i++) {
                                if (i > 0 & i == 1) {
                                    locatorOne = locator.split("=")[i];
                                }
                                if (i > 1) {
                                    locatorOne = locatorOne + "=" + locator.split("=")[i];
                                }
                            }
                            BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locatorOne)));
                            element = BaseTestSetup.driver.findElement(By.xpath(locatorOne));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        else {
                            element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1] + "=" + locator.split("=")[2]));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            else {
                switch (identifier) {
                    case CLASSNAME:
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            return element;
        }
        catch (Exception e) {

            Log.error("Error while identifying the field " + e.getMessage());
            throw new Exception("Error while identifing the element with locator:" + locator + e.getMessage());

        }
    }

    /**
     * wait for element to be clickable and return the element. if locator is
     * erroneous, null value returned.
     * 
     * @param locator
     * @param waitMode
     * @return WebElement
     */
    public WebElement find_Element(String locator, String waitMode) throws Exception {
        WebElement element = null;
        try {
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            if (locator.split("=").length > 2) {
                switch (identifier) {
                    case CLASSNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.className(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.id(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.linkText(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.name(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.tagName(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        String locatorOne = "";
                        if (locator.split("=").length > 3) {
                            for (int i = 0; i < locator.split("=").length; i++) {
                                if (i > 0 && i == 1) {
                                    locatorOne = locator.split("=")[i];
                                }
                                if (i > 1) {
                                    locatorOne = locatorOne + "=" + locator.split("=")[i];
                                }
                            }
                            BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locatorOne)));
                            element = BaseTestSetup.driver.findElement(By.xpath(locatorOne));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        else {
                            element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1] + "=" + locator.split("=")[2]));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            else {
                switch (identifier) {
                    case CLASSNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.className(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.id(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.linkText(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.name(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.tagName(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locator.split("=")[1])));
                        element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1]));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            return element;
        }
        catch (Exception e) {

            Log.error("Please provide correct locator check your locator or sync time, for error message pfb" + e.getMessage());
            throw new Exception("Error while finding the element with locator:" + locator + " :" + e.getMessage());
        }
    }

    public WebElement find_Element(String locator, String waitMode, int n) throws Exception {
        WebElement element = null;
        try {
            System.out.println("Locator:--->" + locator.split("=")[1] + n);
            Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
            if (locator.split("=").length > 2) {
                switch (identifier) {
                    case CLASSNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.className(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.id(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.linkText(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.name(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.tagName(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        String locatorOne = "";
                        if (locator.split("=").length > 3) {
                            for (int i = 0; i < locator.split("=").length; i++) {
                                if (i > 0 && i == 1) {
                                    locatorOne = locator.split("=")[i];
                                }
                                if (i > 1) {
                                    locatorOne = locatorOne + "=" + locator.split("=")[i];
                                }
                            }
                            BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locatorOne + n)));
                            element = BaseTestSetup.driver.findElement(By.xpath(locatorOne + n));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        else {
                            element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1] + "=" + locator.split("=")[2]));
                            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        }
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            else {
                switch (identifier) {
                    case CLASSNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.className(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.className(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case CSSSELECTOR:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.cssSelector(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case ID:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.id(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.id(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case LINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.linkText(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.linkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case NAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.name(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.name(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case PARTIALLINKTEXT:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.partialLinkText(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case TAGNAME:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.tagName(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.tagName(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    case XPATH:
                        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locator.split("=")[1] + n)));
                        element = BaseTestSetup.driver.findElement(By.xpath(locator.split("=")[1] + n));
                        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView();", element);
                        break;
                    default:
                        element = null;
                        System.out.println("Provide correct locator type/category");
                }
            }
            return element;
        }
        catch (Exception e) {

            Log.error("Please provide correct locator check your locator or sync time, for error message pfb" + e.getMessage());
            throw new Exception("Error while finding the element with locator:" + locator + e.getMessage());
        }
    }

    /**
     * clicks the given element
     * 
     * @param element
     */
    public void clickPerform(WebElement element) throws Exception {
        try {
            if (element.isDisplayed()) {
                element.click();
                /*
                 * ((JavascriptExecutor) BaseTestSetup.driver).executeScript(
                 * "arguments[0].click();", element);
                 */
            }
            else {
                ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].style.height='auto'; arguments[0].style.visibility='visible';", element);
                ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].click();", element);
            }
        }
        catch (Exception e) {

            Log.error("Element is not clicked: " + e.getMessage());
            throw new Exception("Error whiile clicking the element with locator:" + element + " :" + e.getMessage());
        }
    }

    /**
     * Enters given value in given web element
     * 
     * @param element
     * @param value
     */
    public void enterValues(WebElement element, String value) throws Exception {
        if (value != null) {
            try {
                element.clear();
                element.click();
                element.sendKeys(value);
                Assert.assertNotNull(element.getText());
                Log.debug("Entered " + value + " into the textbox");
            }
            catch (Exception e) {
                Log.error("Error while entering values please refer above exception, please refer below message /n" + e.getMessage());
                throw new Exception("Error while entering values in the element:" + element + " :" + e.getMessage());
            }
        }
        else {
            System.out.println("Data to be enter is null");
            Log.debug("Data to be entered in the textbox is null");
        }
    }

    /**
     * Enters data and select the same in auto fill text box
     * 
     * @param element
     * @param value
     * @throws Exception
     */
    public void selectElementFromDropdownList(WebElement element, String value) throws Exception {
        try {
            clickPerform(element);
            element.sendKeys(value);
            element.sendKeys(Keys.ENTER);
            Log.debug("Selected the option " + value + "in the dropdown list");
        }
        catch (Exception e) {
            Log.error("Error while  filling auto fill text box please refer below message for details /n" + e.getMessage());
            throw new Exception("Error while selecting a value:" + value + " in the element:" + element + " :" + e.getMessage());
        }
    }

    public void fill_Page(List<?> list, String sheetName, String filePath, Class classname, int i)
            throws Exception {
        String fieldName = null;
        try {
            dataTable.setFilePath(filePath);
            for (String field : dataTable.getLocator(sheetName)) {
                fieldName = field.split(Pattern.quote("|"))[1];
                if (!dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i).equals("SKIP")) {
                    if (field.split(Pattern.quote("|")).length > 3) {
                        ElementType elementType = ElementType.valueOf(field.split(Pattern.quote("|"))[2]);
                        switch (elementType) {
                            case CHECKBOX:
                                if (find_Elements(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i).size() == 1) {
                                    clickPerform(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i));
                                    Log.debug("Clicked on the checkbox: " + find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i));
                                }
                                else {
                                    for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i)) {
                                        if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i))) {
                                            clickPerform(element);
                                            Log.debug("Clicked on checkbox: " + element);
                                            break;
                                        }
                                    }
                                }
                                break;
                            case COMBOBOX:
                                Select select = new Select(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i));
                                BaseTestSetup.waitForAjax(select);
                                if (dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i).contains("=")) {
                                    select.selectByIndex(Integer.parseInt(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[2], list, i).split("=")[1].toString()));
                                    Log.debug("Selected the value " + field.split(Pattern.quote("|"))[2] + " into the combobox");
                                }
                                else {
                                    select.selectByVisibleText(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i));
                                    Log.debug("Selected the value " + field.split(Pattern.quote("|"))[1] + " into the combobox");
                                }
                                break;
                            case RADIOBUTTON:
                                for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i)) {
                                    if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i))) {
                                        clickPerform(element);
                                        Log.debug("Selected the radio button " + element);
                                        break;
                                    }
                                }
                                break;
                            case TEXTAREA:
                                enterValues(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i));
                                break;
                            case TEXTBOX:
                                enterValues(find_Element(field.split(Pattern.quote("|"))[0], field.split(Pattern.quote("|"))[3], i), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i));
                                break;
                            case AUTOFILLTEXTBOX:
                                selectElementFromDropdownList(field.split(Pattern.quote("|"))[0],dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i),field.split(Pattern.quote("|"))[3],i);
                            default:
                                System.out.println("Please verify object repository data");
                                break;
                        }
                    }
                    ElementType elementType = ElementType.valueOf(field.split(Pattern.quote("|"))[2]);
                    switch (elementType) {
                        case CHECKBOX:
                            if (find_Elements(field.split(Pattern.quote("|"))[0], i).size() == 1) {
                                clickPerform(find_Element(field.split(Pattern.quote("|"))[0], i));
                                Log.debug("Clicked on the checkbox: " + find_Element(field.split(Pattern.quote("|"))[0], i));
                            }
                            else {
                                for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0], i)) {
                                    if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i))) {
                                        clickPerform(element);
                                        Log.debug("Clicked on checkbox: " + element);
                                    }
                                    break;
                                }
                            }
                            break;
                        case COMBOBOX:
                            Select select = new Select(find_Element(field.split(Pattern.quote("|"))[0], i));
                            BaseTestSetup.waitForAjax(select);
                            if (dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i).contains("=")) {
                                select.selectByIndex(Integer.parseInt(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i).split("=")[1].toString()));
                            }
                            else {
                                select.selectByVisibleText(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i));
                            }
                            break;
                        case RADIOBUTTON:
                            for (WebElement element : find_Elements(field.split(Pattern.quote("|"))[0], i)) {
                                if (element.getText().equals(dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i))) {
                                    clickPerform(element);
                                    break;
                                }
                            }
                            break;
                        case TEXTAREA:
                            enterValues(find_Element(field.split(Pattern.quote("|"))[0], i), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i));
                            break;
                        case TEXTBOX:
                            enterValues(find_Element(field.split(Pattern.quote("|"))[0], i), dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i));
                            break;
                        case AUTOFILLTEXTBOX:
                        	selectElementFromDropdownList(field.split(Pattern.quote("|"))[0],dataTable.getData(classname, sheetName, field.split(Pattern.quote("|"))[1], list, i),i);
                        default:
                            System.out.println("Please verify object repository data");
                            break;
                    }
                }
            }
        }
        catch (Exception e) {

            Log.error("Error while filling the field: " + fieldName + " please refer below message" + e.getMessage());
            throw new Exception("Error while filling the field:" + fieldName + e.getMessage());
        }
    }

    public By getByLocator(String locator) {
        Identifier identifier = Identifier.valueOf(locator.split("=")[0]);
        switch (identifier) {
            case CLASSNAME:
                byLocator = By.className(locator.split("=")[1]);
                break;
            case CSSSELECTOR:
                byLocator = By.cssSelector(locator.split("=")[1]);
                break;
            case ID:
                byLocator = By.id(locator.split("=")[1]);
                break;
            case LINKTEXT:
                byLocator = By.linkText(locator.split("=")[1]);
                break;
            case NAME:
                byLocator = By.name(locator.split("=")[1]);
                break;
            case PARTIALLINKTEXT:
                byLocator = By.partialLinkText(locator.split("=")[1]);
                break;
            case TAGNAME:
                byLocator = By.tagName(locator.split("=")[1]);
                break;
            case XPATH:
                if (locator.split("=").length > 2) {
                    String locatorOne = "";
                    for (int i = 0; i < locator.split("=").length; i++) {
                        if (i > 0 & i == 1) {
                            locatorOne = locator.split("=")[i];
                        }
                        if (i > 1) {
                            locatorOne = locatorOne + "=" + locator.split("=")[i];
                        }
                    }
                    BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locatorOne)));
                    byLocator = By.xpath(locatorOne);
                }
                else {
                    byLocator = By.xpath(locator.split("=")[1]);
                }
                break;
            default:
                byLocator = null;
                System.out.println("Provide correct locator type/category");
        }
        return byLocator;
    }

    /**
     * This method is to wait for an element until the mentioned time and it
     * will check visibility of the element based on time interval
     * 
     * @param main_menu
     */

    public void fluentWait(By main_menu, int timeInSeconds) throws Exception {
        Wait<WebDriver> wait = new FluentWait<WebDriver>(BaseTestSetup.driver).withTimeout(timeInSeconds, TimeUnit.SECONDS).pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);

        try {
            wait.until(ExpectedConditions.elementToBeClickable(main_menu));
        }
        catch (Exception e) {
            Log.error(e.getMessage());
            throw new Exception("Error while waiting for element with locator " + main_menu + " :" + e.getMessage());
        }
    }

    public Boolean alertToIsPresent() {
        try {
            Boolean status = false;
            BaseTestSetup.wait.until(ExpectedConditions.alertIsPresent());
            BaseTestSetup.driver.switchTo().alert().accept();
            status = true;
            return status;
        }
        catch (Exception e) {
            Log.error(e.getMessage());
            return false;
        }
    }

    public void mouseOver(By by) {
        try {
            WebElement element = BaseTestSetup.driver.findElement(by);
            Actions action = new Actions(BaseTestSetup.driver);
            action.moveToElement(element).build().perform();
        }
        catch (Exception e) {
            Log.info(e.getMessage());
        }
    }

    /**
     * close all child windows
     * 
     * @param parentHandle
     */
    public void closeAllChildWindows(String parentHandle) {
        for (String window : BaseTestSetup.driver.getWindowHandles()) {
            if (!window.equals(parentHandle)) {
                BaseTestSetup.driver.switchTo().window(window);
                BaseTestSetup.driver.close();
            }
        }
        BaseTestSetup.driver.switchTo().window(parentHandle);
    }

    public void jsClickPerform(By by) throws Exception {
        try {
            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].style.height='auto'; arguments[0].style.visibility='visible';", BaseTestSetup.driver.findElement(by));
            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].click();", BaseTestSetup.driver.findElement(by));
        }
        catch (Exception e) {

            Log.error("Failed while performing JS click operation for the element located by : " + by);
            throw new Exception("Error while clicking the element with identifier " + by + e.getMessage());
        }
    }
}